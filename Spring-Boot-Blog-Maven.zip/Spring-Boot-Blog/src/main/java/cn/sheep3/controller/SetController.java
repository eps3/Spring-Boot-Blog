package cn.sheep3.controller;

import org.springframework.stereotype.Controller;

/**
 * Created by sheep3 on 16-9-18.
 */
@Controller
public class SetController {

}
