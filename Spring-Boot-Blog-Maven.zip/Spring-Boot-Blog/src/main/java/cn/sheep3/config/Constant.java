package cn.sheep3.config;

/**
 * Created by sheep3 on 16-9-17.
 */
public class Constant {

    public static final String PAGE_CACHE_NAME = "page_cache_name";
    public static final String TAG_CACHE_NAME = "tag_cache_name";
    public static final String POST_CACHE_NAME = "post_cache_name";
    public static final String USER_CACHE_NAME = "user_cache_name";
}

