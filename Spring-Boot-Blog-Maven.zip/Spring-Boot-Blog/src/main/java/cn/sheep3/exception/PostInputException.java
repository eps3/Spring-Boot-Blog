package cn.sheep3.exception;

/**
 * Created by sheep3 on 16-9-16.
 */
public class PostInputException extends Exception {
    public PostInputException(String message){
        super(message);
    }
}
